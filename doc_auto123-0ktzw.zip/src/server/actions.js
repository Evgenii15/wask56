import HttpError from '@wasp/core/HttpError.js'
import { Document } from '@server/models'
import { fill_template } from '@server/utils'

export const uploadDocument = async (args, context) => {
  const { filepath, userId } = args;

  if (!context.user) { throw new HttpError(401) };

  const document = await context.entities.Document.create({
    data: {
      filepath: filepath,
      filledFilepath: null,
      userId: userId
    }
  });

  return document;
}

export const fillDocument = async (args, context) => {
  const { filepath, data } = args;

  const filledFilepath = await fill_template(filepath, data);
  const document = await context.entities.Document.findUnique({ where: { filepath } });
  await context.entities.Document.update({ where: { filepath }, data: { filledFilepath } });

  return filledFilepath;
}
