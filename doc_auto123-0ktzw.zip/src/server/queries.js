import HttpError from '@wasp/core/HttpError.js'

export const getDocuments = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }

  return context.entities.Document.findMany({
    where: {
      userId: context.user.id
    }
  });
}

export const getDocument = async (args, context) => {
  const document = await context.entities.Document.findUnique({
    where: { id: args.id },
    include: { User: true }
  });

  if (!document) throw new HttpError(404, 'No document with id ' + args.id);

  return document;
}
