import React from 'react';
import { useState } from 'react';


export function HomePage() {
  const [fileName, setFileName] = useState('');
  const [isValid, setIsValid] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isDownloadVisible, setIsDownloadVisible] = useState(false);

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    setFileName(file ? file.name : '');
  };

  const validateForm = (e) => {
    e.preventDefault();
    const inputs = document.querySelectorAll('input[required]');
    let valid = true;
    inputs.forEach((input) => {
      if (input.value.trim() === '') {
        input.classList.add('border-red-500');
        valid = false;
      } else {
        input.classList.remove('border-red-500');
      }
    });
    setIsValid(valid);
    if (valid) {
      setIsProcessing(true);
      setTimeout(() => {
        setIsProcessing(false);
        setIsDownloadVisible(true);
      }, 2000);
    }
  };

  return (
    <div className='flex flex-col min-h-screen justify-between'>
      <div className='py-6 px-6'>
        <h1 className='text-3xl font-bold text-slate-900'>Automatic Document Filling</h1>
      </div>
      <div className='py-4 px-6'>
        <p className='text-base font-normal text-slate-500'>Upload your template and provide the necessary data for automatic document filling.</p>
      </div>
      <div className='py-4 px-6'>
        <div className='flex items-center justify-center'>
          <label htmlFor='file-upload' className='px-3 py-2 bg-slate-900 text-white rounded-2xl cursor-pointer hover:bg-slate-700'>
            Select File
          </label>
          <input id='file-upload' type='file' className='hidden' onChange={handleFileUpload} />
          <p id='file-name' className='ml-4 text-base font-normal text-slate-500'>{fileName}</p>
        </div>
      </div>
      <div className='py-4 px-6'>
        <form onSubmit={validateForm}>
          <div className='grid grid-cols-1 gap-y-4'>
            <div>
              <label htmlFor='full-name' className='text-base font-normal text-slate-900'>{{??????_????????????????}}</label>
              <input id='full-name' type='text' className={`w-full px-3 py-2 border rounded-xl border-slate-200 outline-0 ring-1 ring-inset ring-slate-300 focus-visible:outline-2 ${!isValid ? 'border-red-500' : ''}`} required />
            </div>
            <div>
              <label htmlFor='cost-numbers' className='text-base font-normal text-slate-900'>{{??????????????????_??????????????}}</label>
              <input id='cost-numbers' type='text' className={`w-full px-3 py-2 border rounded-xl border-slate-200 outline-0 ring-1 ring-inset ring-slate-300 focus-visible:outline-2 ${!isValid ? 'border-red-500' : ''}`} required />
            </div>
            <div>
              <label htmlFor='cost-words' className='text-base font-normal text-slate-900'>{{??????????????????_????????????????}}</label>
              <input id='cost-words' type='text' className={`w-full px-3 py-2 border rounded-xl border-slate-200 outline-0 ring-1 ring-inset ring-slate-300 focus-visible:outline-2 ${!isValid ? 'border-red-500' : ''}`} required />
            </div>
            <div>
              <label htmlFor='dob' className='text-base font-normal text-slate-900'>{{????????_????????????????}}</label>
              <input id='dob' type='text' className={`w-full px-3 py-2 border rounded-xl border-slate-200 outline-0 ring-1 ring-inset ring-slate-300 focus-visible:outline-2 ${!isValid ? 'border-red-500' : ''}`} required />
            </div>
            <div>
              <label htmlFor='reg-address' className='text-base font-normal text-slate-900'>{{??????????_??????????????????????}}</label>
              <input id='reg-address' type='text' className={`w-full px-3 py-2 border rounded-xl border-slate-200 outline-0 ring-1 ring-inset ring-slate-300 focus-visible:outline-2 ${!isValid ? 'border-red-500' : ''}`} required />
            </div>
            <div>
              <label htmlFor='passport-series' className='text-base font-normal text-slate-900'>{{??????????????_??????????}}</label>
              <input id='passport-series' type='text' className={`w-full px-3 py-2 border rounded-xl border-slate-200 outline-0 ring-1 ring-inset ring-slate-300 focus-visible:outline-2 ${!isValid ? 'border-red-500' : ''}`} required />
            </div>
            <div>
              <label htmlFor='passport-number' className='text-base font-normal text-slate-900'>{{??????????????_??????????}}</label>
              <input id='passport-number' type='text' className={`w-full px-3 py-2 border rounded-xl border-slate-200 outline-0 ring-1 ring-inset ring-slate-300 focus-visible:outline-2 ${!isValid ? 'border-red-500' : ''}`} required />
            </div>
            <div>
              <label htmlFor='issued-by' className='text-base font-normal text-slate-900'>{{??????_??????????}}</label>
              <input id='issued-by' type='text' className={`w-full px-3 py-2 border rounded-xl border-slate-200 outline-0 ring-1 ring-inset ring-slate-300 focus-visible:outline-2 ${!isValid ? 'border-red-500' : ''}`} required />
            </div>
            <div>
              <label htmlFor='snils-number' className='text-base font-normal text-slate-900'>{{??????????}}</label>
              <input id='snils-number' type='text' className={`w-full px-3 py-2 border rounded-xl border-slate-200 outline-0 ring-1 ring-inset ring-slate-300 focus-visible:outline-2 ${!isValid ? 'border-red-500' : ''}`} required />
            </div>
            <div>
              <label htmlFor='email' className='text-base font-normal text-slate-900'>{{??????????_????_??????????}}</label>
              <input id='email' type='email' className={`w-full px-3 py-2 border rounded-xl border-slate-200 outline-0 ring-1 ring-inset ring-slate-300 focus-visible:outline-2 ${!isValid ? 'border-red-500' : ''}`} required />
            </div>
            <div>
              <label htmlFor='phone' className='text-base font-normal text-slate-900'>{{??????????_????????????????}}</label>
              <input id='phone' type='tel' className={`w-full px-3 py-2 border rounded-xl border-slate-200 outline-0 ring-1 ring-inset ring-slate-300 focus-visible:outline-2 ${!isValid ? 'border-red-500' : ''}`} required />
            </div>
            <div>
              <label htmlFor='short-full-name' className='text-base font-normal text-slate-900'>{{??????_????????????????????}}</label>
              <input id='short-full-name' type='text' className={`w-full px-3 py-2 border rounded-xl border-slate-200 outline-0 ring-1 ring-inset ring-slate-300 focus-visible:outline-2 ${!isValid ? 'border-red-500' : ''}`} required />
            </div>
          </div>
          <div className='mt-4'>
            <button type='submit' className='px-4 py-2 bg-slate-900 text-white rounded-xl hover:bg-slate-700'>
              Submit
            </button>
          </div>
        </form>
      </div>
      <div className='py-4 px-6'>
        <button
          id='fill-button'
          className='px-3.5 py-2.5 bg-slate-900 text-white rounded-2xl'
          onClick={fillDocument}
          disabled={isProcessing}
        >
          {isProcessing ? 'Processing...' : 'Fill Document'}
        </button>
        <div id='loading-indicator' className={`mt-2 ml-2 inline-flex items-center ${isProcessing ? '' : 'hidden'}`}>
          <div className='animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-slate-900'></div>
          <span className='ml-2 text-base font-normal text-slate-900'>Processing...</span>
        </div>
      </div>
      <div id='download-link' className={`py-4 px-6 ${isDownloadVisible ? '' : 'hidden'}`}>
        <a href='#' className='text-base font-semibold text-slate-900 hover:underline'>Download Filled Document</a>
      </div>
      <div className='py-4 px-6'>
        <h2 className='text-lg font-semibold text-slate-900'>FAQ / Instructions</h2>
        <ul className='list-disc pl-4 mt-2'>
          <li className='text-base font-normal text-slate-700'>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
          <li className='text-base font-normal text-slate-700'>Nullam auctor, nunc id aliquam ultricies, nunc nunc ultricies nunc, id aliquam nunc nunc id.</li>
          <li className='text-base font-normal text-slate-700'>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</li>
        </ul>
      </div>
    </div>
  );
}