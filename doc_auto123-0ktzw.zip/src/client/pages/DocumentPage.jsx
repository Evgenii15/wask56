import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@wasp/queries';
import getDocument from '@wasp/queries/getDocument';

export function DocumentPage() {
  const { documentId } = useParams();
  const { data: document, isLoading, error } = useQuery(getDocument, { id: documentId });

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold text-slate-900">Document Details</h1>
      <div className="py-4">
        <h2 className="text-lg font-semibold text-slate-900">Document ID: {document.id}</h2>
        <p className="text-base font-normal text-slate-500">User: {document.User.username}</p>
        <div className="py-2">
          <button className="px-4 py-2 bg-slate-900 text-white rounded-xl hover:bg-slate-700">Download Original Document</button>
          <button className="px-4 py-2 bg-slate-900 text-white rounded-xl hover:bg-slate-700 ml-2">Download Filled Document</button>
        </div>
      </div>
    </div>
  );
}